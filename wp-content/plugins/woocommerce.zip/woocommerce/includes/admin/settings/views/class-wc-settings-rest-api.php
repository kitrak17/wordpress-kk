<?php // @codingStandardsIgnoreFile.
/**
 * Settings class file.
 *
 * @deprecated 3.4.0 Replaced with class-wc-settings-advanced.php.
 * @todo remove in 4.0.
 */

defined( 'ABSPATH' ) || exit;

return include __DIR__ . '/class-wc-settings-advanced.php';
