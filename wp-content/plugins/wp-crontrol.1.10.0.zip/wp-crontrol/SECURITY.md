# Security Policy

## Reporting a Vulnerability

If you discover a security issue in WP Crontrol, please report it to [the security program on HackerOne](https://hackerone.com/johnblackbourn). Do not report security issues on GitHub or the WordPress.org support forums. Thank you.
